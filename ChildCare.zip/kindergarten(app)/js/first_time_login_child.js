function tabE(obj,e){ 
  var e=(typeof event!='undefined')?window.event:e;// IE : Moz 
  if(e.keyCode==13){ 
    var ele = document.forms[0].elements; 
    for(var i=0;i<ele.length;i++){ 
      var q=(i==ele.length-1)?0:i+1;// if last element : if any other 
      if(obj==ele[i]){ele[q].focus();break} 
    } 
    return false; 
  } 
} 

var modal1 = document.getElementById('myModal1');

var btn = document.getElementById("myBtn");

var yes = document.getElementById("yes");

var no = document.getElementsByClassName("no")[0];

btn.onclick = function() {
    modal1.style.display = "block";
}

no.onclick = function() {
    modal1.style.display = "none";
}

yes.onclick = function() {
  window.location.href = "guardian_home.html";
}

function myFunction() {
  var numbers = /[0-9]/g;
  var lowerCaseLetters = /[a-z]/g;
  var upperCaseLetters = /[A-Z]/g;

  var fname = document.getElementById("fname");
  var lname = document.getElementById("lname");
  var BirthCertificateNumber = document.getElementById("BirthCertificateNumber");
  var Reminder = document.getElementById("Reminder");
  var Height = document.getElementById("Height");
  var Weight = document.getElementById("Weight");
  var Age = document.getElementById("Age");
  var checkbox = document.getElementById("checkbox");

  if (fname.value.match(numbers) || fname.value == "") {
    fname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (lname.value.match(numbers) || lname.value == "") {
    lname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (BirthCertificateNumber.value.match(lowerCaseLetters) || BirthCertificateNumber.value.match(upperCaseLetters) || BirthCertificateNumber.value == "") { 
    BirthCertificateNumber.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Reminder.value == "") {
    Reminder.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Height.value.match(lowerCaseLetters) || Height.value.match(upperCaseLetters) || Height.value == "") { 
    Height.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Weight.value.match(lowerCaseLetters) || Weight.value.match(upperCaseLetters) || Weight.value == "") { 
    Weight.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Age.value.match(lowerCaseLetters) || Age.value.match(upperCaseLetters) || Age.value == "" || (Age.value >= 6 || Age.value <= 2)) { 
    Age.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (checkbox.checked == false) {
    snackbar.innerHTML = "Please agree terms";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else{
    document.getElementById("regForm").submit();
    window.location.href = "student_home.html";
  }
}
function tabE(obj,e){ 
  var e=(typeof event!='undefined')?window.event:e;// IE : Moz 
  if(e.keyCode==13){ 
    var ele = document.forms[0].elements; 
    for(var i=0;i<ele.length;i++){ 
      var q=(i==ele.length-1)?0:i+1;// if last element : if any other 
      if(obj==ele[i]){ele[q].focus();break} 
    } 
    return false; 
  } 
} 

var modal = document.getElementById('myModal');

var btn = document.getElementById("myBtn");

var yes = document.getElementById("yes");

var no = document.getElementsByClassName("no")[0];

btn.onclick = function() {
    modal.style.display = "block";
}

no.onclick = function() {
    modal.style.display = "none";
}

yes.onclick = function() {
  window.location.href = "index.html";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function myFunction() {
  var numbers = /[0-9]/g;
  var lowerCaseLetters = /[a-z]/g;
  var upperCaseLetters = /[A-Z]/g;

  var fname = document.getElementById("fname");
  var lname = document.getElementById("lname");
  var ph = document.getElementById("ph");
  var email = document.getElementById("email");
  var myInput = document.getElementById("psw");
  var Repeatpsw = document.getElementById("Repeatpsw");
  var checkbox = document.getElementById("checkbox");
  var address = document.getElementById("address");

  if (fname.value.match(numbers) || fname.value == "") {
    fname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (lname.value.match(numbers) || lname.value == "") {
    lname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (email.value == "") {
    email.className = " wrong";
    snackbar.innerHTML = "Please complete form";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (ph.value.match(lowerCaseLetters) || ph.value.match(upperCaseLetters) || ph.value == "") { 
    ph.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (address.value == "") {
    address.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (myInput.value == "") {
    myInput.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Repeatpsw.value == "") {
    Repeatpsw.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Repeatpsw.value != myInput.value) {
    Repeatpsw.className = " wrong";
    snackbar.innerHTML = "Password not same";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (checkbox.checked == false) {
    snackbar.innerHTML = "Please agree terms";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else{
    $("#Submit").click(function() {
      var firstName = $("#fname").val();
      var lastName = $("#lname").val();
      var email = $("#email").val();
      var phone = $("#ph").val();
      var address = $("#address").val();
      var password = $("#psw").val();
      var dataString = "fname=" + firstName + "&lname=" + lastName + "&pword=" + password +  "&email=" + email + "&phone=" + phone + "&address=" + address;
      $.ajax({
        type: "POST",
        url: "http://localhost/kindergarten/php/first_time_login_teacher.php",
        data: dataString,
        crossDomain: true,
        cache: false,
        success: function(data) {
          if (data == 1) {
            alert("First Time Login Completed");
            window.location.href = "Teacher_home.html"
          }else {
            alert("error");
            alert(data);
          }
        }
      });

    });
  }
}

function ShowPassword(){
  var myInput = document.getElementById("psw");
  var Repeatpsw = document.getElementById("Repeatpsw");

  if (myInput.type === "password"){
    myInput.type = "text";
    Repeatpsw.type = "text";
  }else{
    myInput.type = "password";
    Repeatpsw.type = "password";
  }
}

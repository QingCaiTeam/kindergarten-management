var modal1 = document.getElementById('myModal1');

function tabE(obj,e){ 
  var e=(typeof event!='undefined')?window.event:e;// IE : Moz 
  if(e.keyCode==13){ 
    var ele = document.forms[0].elements; 
    for(var i=0;i<ele.length;i++){ 
      var q=(i==ele.length-1)?0:i+1;// if last element : if any other 
      if(obj==ele[i]){ele[q].focus();break} 
    } 
    return false; 
  } 
} 

function myFunction() {
  var numbers = /[0-9]/g;
  var lowerCaseLetters = /[a-z]/g;
  var upperCaseLetters = /[A-Z]/g;

  var fname = document.getElementById("fname");
  var lname = document.getElementById("lname");
  var ph = document.getElementById("ph");
  var email = document.getElementById("email");
  var myInput = document.getElementById("psw");
  var Repeatpsw = document.getElementById("Repeatpsw");
  var checkbox = document.getElementById("checkbox");
  var username = document.getElementById("username");
  var address = document.getElementById("address");

  if (fname.value.match(numbers) || fname.value == "") {
    fname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (lname.value.match(numbers) || lname.value == "") {
    lname.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (email.value == "") {
    email.className = " wrong";
    snackbar.innerHTML = "Please complete form";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (ph.value.match(lowerCaseLetters) || ph.value.match(upperCaseLetters) || ph.value == "") { 
    ph.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (address.value == "") {
    address.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (myInput.value == "") {
    myInput.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Repeatpsw.value == "") {
    Repeatpsw.className = " wrong";
    snackbar.innerHTML = "Please insert in format";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else if (Repeatpsw.value != myInput.value) {
    Repeatpsw.className = " wrong";
    snackbar.innerHTML = "Password not same";
    snackbar.className = "show";
    setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
  }else{
    modal1.style.display = "block";
  }
}

var span1 = document.getElementsByClassName("close1")[0];

span1.onclick = function() {
    modal1.style.display = "none";
}

// var btn2 = document.getElementById("myBtn2");

// btn2.onclick = function() {
//     modal1.style.display = "none";
//     document.getElementById("regForm").submit();
//     window.location.href = "guardian_home.html";
// }

function ShowPassword(){
  var myInput = document.getElementById("psw");
  var Repeatpsw = document.getElementById("Repeatpsw");

  if (myInput.type === "password"){
    myInput.type = "text";
    Repeatpsw.type = "text";
  }else{
    myInput.type = "password";
    Repeatpsw.type = "password";
  }
}

function One(){
  var preview = document.querySelector('#img1');
  var file    = document.querySelector('#file1').files[0]; 
  var DeletePicture = document.querySelector("#DeletePicture");
  var reader  = new FileReader();

  reader.onloadend = function () {
      preview.src = reader.result;
  }

  DeletePicture.onclick = function(){
    preview.src = "";
    document.getElementById("display").style.display = "none";
  }

  if (file) {
    reader.readAsDataURL(file); 
    document.getElementById("display").style.display = "block";
  } else {
    
  }
}

One();
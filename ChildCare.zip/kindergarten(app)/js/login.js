function tabE(obj,e){ 
            var e=(typeof event!='undefined')?window.event:e;// IE : Moz 
            if(e.keyCode==13){ 
                var ele = document.forms[0].elements; 
                for(var i=0;i<ele.length;i++){ 
                    var q=(i==ele.length-1)?0:i+1;// if last element : if any other 
                    if(obj==ele[i]){ele[q].focus();break} 
                } 
                return false; 
            } 
        } 

        function ShowPassword(){
          var myInput = document.getElementById("password");

          if (myInput.type === "password"){
            myInput.type = "text";
        }else{
            myInput.type = "password";
        }
    }

    function myFunction() {
        var snackbar = document.getElementById("snackbar");
        var userID = document.getElementById("userID");
        var password = document.getElementById("password");

        if (userID.value == "") {
            snackbar.innerHTML = "Please insert User ID";
            snackbar.className = "show";
            setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
        }else if (password.value == "") {
            snackbar.innerHTML = "Please insert paswword";
            snackbar.className = "show";
            setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
        }else{
                var userID = $("#userID").val().trim();
                var password = $("#password").val().trim();
                var dataString = "userID="+ userID +"&password="+password;
                alert(dataString);
                if( userID != "" && password != "" ){
                    $.ajax({
                        url:'php/login.php',
                        type:'POST',
                        data:dataString,
                        success:function(response){
                            alert(response);
                            setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
                            if(response == 1){
                                var url = "php/teacher.php";
                                $.getJSON(url, function(result){
                                    console.log(result);
                                    $.each(result, function(i, field) {
                                        var profileStatus = field.profileStatus;
                                        if(profileStatus == 0){
                                            window.location = "first_time_login_teacher.html"
                                        }else if(profileStatus == 1){
                                            window.location = "Teacher_home.html";
                                        }  
                                    }); 
                                });
                            }else if (response == 2) {
                                var url = "php/guardian.php";
                                $.getJSON(url, function(result){
                                    console.log(result);
                                    $.each(result, function(i, field) {
                                        var profileStatus = field.profileStatus;
                                        if(profileStatus == 0){
                                            window.location = "first_time_login_guardian.html"
                                        }else if(profileStatus == 1){
                                            window.location = "guardian_home.html";
                                        }  
                                    }); 
                                });
                            }else{
                                snackbar.innerHTML = "Invalid user ID and password!";
                                snackbar.className = "show";
                                setTimeout(function(){ snackbar.className = snackbar.className.replace("show", ""); }, 3000);
                            }                                   
                        }
                    });
                }
        }

    }
var body = document.getElementById("body");

function openNav() {
    document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
}

var modal1 = document.getElementById('myModal1');

var btn = document.getElementById("myBtn");

var yes = document.getElementById("yes");

var no = document.getElementsByClassName("no")[0];

btn.onclick = function() {
    modal1.style.display = "block";
}

no.onclick = function() {
    modal1.style.display = "none";
}

yes.onclick = function() {
  window.location.href = "guardian_home.html";
}

window.onclick = function(event) {
	if (event.target == modal1) {
        modal1.style.display = "none";
    }
}
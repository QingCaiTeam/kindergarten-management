<?php
include("config.php");

if(!isset($_SESSION['userTID'])){
	header('Location: ../index.html');
}else{
	$un = $_SESSION['userTID'];

	$chkPST = "SELECT profileStatus FROM teacher WHERE userID = '$un'";
	$rchkPST = $conn->query($chkPST);

	if($rchkPST ->num_rows >0){
		while($row = $rchkPST->fetch_assoc()) {
			$pST = $row['profileStatus'];

			if($pST == 0){
				$_SESSION['userTID'] = $un; 
				header("location:../first_time_login_teacher.html");	
			}
			else{
				$_SESSION['userTID'] = $un; 
				header("location:../Teacher_home.html");
			}

		}

	}

}

$conn->close();
?>
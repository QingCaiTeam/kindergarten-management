 <?php
include("config.php");

$uTID=$_SESSION['userTID'] ;

$sql = "SELECT * from teacher where userID = '$uTID'";
$result = $conn->query($sql);

if ($result->num_rows >0) {	
	
	while($row = $result->fetch_assoc()) {
		$data[]=$row;
		$_SESSION['userTID'] = $uTID;
	}
}else {
}
echo json_encode($data);

$conn->close();
?>
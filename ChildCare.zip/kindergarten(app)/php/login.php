<?php
include("config.php");

$userID =$_POST['userID'];
$password =$_POST['password'];
$password = md5($password);

	// $username =mysql_real_escape_string($conn,$_POST['username']);
	// $password =mysql_real_escape_string($conn,$_POST['password']);
	$sqlTU = "SELECT * from teacher where userID = '$userID' AND  password = '$password'";
	$resultTU = $conn->query($sqlTU);

if ($resultTU->num_rows >0) {		
	$_SESSION['userTID'] = $userID; 
	echo 1;	

}else if($resultTU->num_rows <=0){
	$sqlGU = "SELECT * from guardian where userID = '$userID' AND  password = '$password'";
	$resultGU = $conn->query($sqlGU);

if($resultGU->num_rows >0){
		$_SESSION['userGID'] = $userID; 
		echo 2;
	}
}


// if($resultTU->num_rows >0){
// 	$_SESSION['userTID'] = $userID; 
// 	echo 2;
// }

$conn->close();	

?>
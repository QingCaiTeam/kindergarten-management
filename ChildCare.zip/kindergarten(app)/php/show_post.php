<?php
include("config.php");

$uID = $_SESSION['userTID'];

$sql = "SELECT post.*,teacher.userID,teacher.firstName,teacher.lastName from post LEFT JOIN teacher ON post.poster = teacher.userID where teacher.userID = '$uID' ORDER BY post.DateTime DESC" ;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row 
    while($row = $result->fetch_assoc()) {
    	$_SESSION['userGID'] = $uID;
        $data[]=$row;

    }
} else {
    echo "0 results";
}
echo json_encode($data);

$conn->close();
?>

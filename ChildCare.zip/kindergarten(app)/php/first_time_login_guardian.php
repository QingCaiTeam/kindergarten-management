<?php
include("config.php");

$uID = $_SESSION['userGID'];

// $fN = "Tan";
// $lN = "Pei Hong";
// $email = "hong1999@hotmail.com";
// $phone = "0184353434";
// $username = "Hong1999";
// $pass = "pei";

$fN = $_POST['fname'];
$lN = $_POST['lname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$pass = $_POST['pword'];

$sql = "UPDATE guardian SET firstName = '$fN' , lastName = '$lN', email = '$email', phone = '$phone',address = '$address', password = '$pass' WHERE userID = '$uID'";

if ($conn->query($sql) === TRUE) {
	$sPD = "UPDATE guardian SET profileStatus = '1'WHERE userID ='$uID'";
	if ($conn->query($sPD) === TRUE) {
		$_SESSION['userGID'] = $uID;
		echo 1;
	} else {
		echo "Error updating record: " . $conn->error;
	}
}else{
	echo "Error updating record: " . $conn->error;
}	


$conn->close();
?>

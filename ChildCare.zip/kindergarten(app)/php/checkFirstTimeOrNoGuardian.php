<?php
include("config.php");

if(!isset($_SESSION['userGID'])){
	header('Location: ../index.html');
}else{
	$un = $_SESSION['userGID'];


	$chkPSG = "SELECT profileStatus FROM guardian WHERE userID = '$un'";
	$rchkPSG = $conn->query($chkPSG);

	if($rchkPSG ->num_rows >0){
		while($row = $rchkPSG->fetch_assoc()) {
			$pSG = $row['profileStatus'];

			if($pSG == 0){
				$_SESSION['userGID'] = $un; 
				header("location:../first_time_login_guardian.html");	
			}
			else{
				$_SESSION['userGID'] = $un; 
				header("location:../guardian_home.html");
			}

		}

	}

}
$conn->close();
?>
<?php
include("config.php");

$classS=$_SESSION['classS'];

$sql = "SELECT post.*,teacher.firstName,teacher.lastName FROM post LEFT JOIN teacher ON post.poster=teacher.userID WHERE post.class = '$classS' ORDER BY DateTime DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $data[]=$row;
    }
} else {
    echo "0 results";
}
echo json_encode($data);

$conn->close();
?>
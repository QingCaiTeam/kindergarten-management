<?php
include("config.php");

$uSID=$_POST['userSID'];
$classS=$_POST['classS'];

$sql = "SELECT * from student where userID = '$uSID'";
$result = $conn->query($sql);

if ($result->num_rows >0) {		
	
	while($row = $result->fetch_assoc()) {
		$data[]=$row;
		$_SESSION['userSID'] = $uSID;
		$_SESSION['classS'] = $classS;
	}
}else {
}
echo json_encode($data);

$conn->close();
?>
<?php
include("config.php");

$userID = $_POST['userTID'];

$sql = "SELECT * from teacher where userID = '$userID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	while($row = $result->fetch_assoc()) {
		$_SESSION['userTID'] = $userID;
		$data[]=$row;

	}
}else {
	echo "0 results";
}
echo json_encode($data);

$conn->close();

?>
<?php
include("config.php");
if(isset($_POST['update']))
{
	$uID=$_POST['userID'];
	$firstN=$_POST['fname'];
	$lastN=$_POST['lname'];
	$birthCN=$_POST['birthCN'];
	$reminder=$_POST['reminder'];
	$height = $_POST['height'];
	$weight = $_POST['weight'];
	$age = $_POST['age'];

	$sql = "UPDATE student SET firstName = '$firstN' , lastName = '$lastN', BirthCN = '$birthCN', reminder = '$reminder',height = '$height', weight = '$weight', age = '$age' WHERE userID = '$uID'";

	if ($conn->query($sql) === TRUE) {
		echo "success";
		// header("location:home.php");
	}else{
		echo "error" . $conn->error;
	}	

}
?>
<?php

include("config.php");

$uID = $_SESSION['userGID'];

$sql = "SELECT * from student where guardianID = '$uID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    	$_SESSION['userGID'] = $uID;
        $data[]=$row;
    }
} else {
    echo "0 results";
}
echo json_encode($data);

$conn->close();
?>